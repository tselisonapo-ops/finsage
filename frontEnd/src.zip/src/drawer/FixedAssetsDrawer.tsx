import { useEffect, useMemo, useState } from "react";
import DrawerShell from "./DrawerShell";

export type FixedAssetsDrawerMode = "acquire" | "dispose";

/** -----------------------------
 *  Typed globals
 *  ----------------------------- */
type ApiFetch = (url: string, opts?: RequestInit) => Promise<unknown>;

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function readPostingDateFromArgs(args: FixedAssetsDrawerOpenArgs | null): string {
  const d = args?.defaults || {};
  const ctx = (window as unknown as {
    __FS_POSTING_CONTEXT__?: {
      posting_date?: string;
      postingDate?: string;
      date?: string;
    };
  }).__FS_POSTING_CONTEXT__;

  return String(
    d.posting_date ||
    d.postingDate ||
    d.date ||
    d.acquisitionDate ||
    ctx?.posting_date ||
    ctx?.postingDate ||
    ctx?.date ||
    ""
  ).trim();
}

function readJournalRefFromArgs(args: FixedAssetsDrawerOpenArgs | null): string {
  const d = args?.defaults || {};
  return String(
    d.reference ||
    (window as unknown as { __FS_POSTING_CONTEXT__?: { journal_ref?: string } })
      .__FS_POSTING_CONTEXT__?.journal_ref ||
    ""
  ).trim();
}

function getApiFetch(): ApiFetch | undefined {
  return (window as unknown as { apiFetch?: ApiFetch }).apiFetch;
}

type Endpoints = {
  coa?: { list?: (cid: number | string) => string };
  assets?: { create?: (cid: number | string) => string };
  vendors?: { list?: (cid: number | string, q?: { limit?: number; offset?: number; q?: string }) => string };
  banks?: { list?: (cid: number | string, q?: { limit?: number; offset?: number }) => string };
};

const ENDPOINTS = (window as unknown as { ENDPOINTS?: Endpoints }).ENDPOINTS;

/** -----------------------------
 *  Public args/result
 *  ----------------------------- */
export type FixedAssetsDrawerOpenArgs = {
  companyId: number | string;
  mode: FixedAssetsDrawerMode;
  companyName?: string;
  accountCode?: string;
  accountName?: string;
  assetId?: number | string;
  defaults?: Record<string, unknown>;
};

export type FixedAssetsDrawerResult =
  | { action: "close" }
  | { action: "select_asset"; assetId: number | string }
  | { action: "create_asset"; assetId: number | string };

type Props = {
  open: boolean;
  args: FixedAssetsDrawerOpenArgs | null;
  onClose: () => void;
  onResolve: (res: FixedAssetsDrawerResult) => void;
};

/** -----------------------------
 *  Types
 *  ----------------------------- */
type Vendor = { id: number | string; name?: string; vendor_name?: string };
type BankAccount = {
  id: number | string;
  bank_name?: string;
  account_name?: string;
  account_number?: string;
  ledger_account_code?: string | null; // ✅ used for posting
};

type FundingSource = "cash" | "bank" | "grni" | "vendor_credit" | "other";
type SourceDocType = "invoice" | "grn";
type JournalLine = { account_code: string; account_name?: string; debit: number; credit: number; memo?: string };
type UopUsageMode = "DELTA" | "READING";

type AssetEntryMode = "acquisition" | "opening_balance";


type CoaRow = {
  code: string;
  name?: string;
  account_name?: string;

  category?: string;
  section?: string;
  cf_bucket?: string;
  cf_section?: string;

  description?: string;
  posting?: boolean;
  posting_rules?: string;
  standard?: string;

  type?: string;
  group?: string;
  statement?: string;

  // add these
  is_contra?: boolean;
  role?: string;
};

type DepreciationMethod = "" | "SL" | "RB" | "UOP" | "APP";

export type AccountingStandard = "ias16" | "ias40" | "ias38";
export type AssetNature = "tangible" | "intangible";

type AssetComponentDraft = {
  component_type: "land" | "building" | string;
  asset_name: string;
  asset_class_group: string;
  asset_class: string;
  cost: number;
  depreciation_method: DepreciationMethod;
  useful_life_months: number;
  measurement_model: "cost" | "revaluation";
};

type VatRecoveryReason =
  | ""
  | "commercial_vehicle"
  | "passenger_vehicle_disallowed"
  | "production_income_use"
  | "mixed_use"
  | "dealer_stock"
  | "rental_fleet"
  | "taxi_transport"
  | "not_registered_or_exempt";

// Add to the type constants

// Expand ASSET_CLASS_GROUPS to include IAS 40 and IAS 38 groups
const ASSET_CLASS_GROUPS = [
  // --- IAS 16 (existing) ---
  "Land",
  "Buildings",
  "Land and buildings",
  "Plant and machinery",
  "Vehicles",
  "Motorcycles / bikes",
  "Bicycles",
  "Scooters",
  "Heavy vehicles",
  "Construction equipment",
  "Mining equipment",
  "Manufacturing equipment",
  "Computer equipment",
  "Office equipment",
  "Furniture and fittings",
  "Tools and small equipment",
  "Leasehold improvements",
  "Assets under construction",
  "Other PPE",
  // --- IAS 40 (Investment Property) ---
  "Investment property - Land",
  "Investment property - Buildings",
  "Investment property - Under construction",
  // --- IAS 38 (Intangible Assets) ---
  "Goodwill",
  "Patents",
  "Copyrights",
  "Trademarks",
  "Software",
  "Licences",
  "Franchises",
  "Customer lists",
  "Research and development",
  "Other intangible assets",
] as const;

type AssetClassGroup = typeof ASSET_CLASS_GROUPS[number];

type CreateAssetPayload = {
  entry_mode?: AssetEntryMode;
  posting_date?: string | null;
  reference?: string | null;

  asset_code: string;
  asset_name: string;
  asset_class: string;
  asset_class_group?: AssetClassGroup | string | null;
  category?: string | null;

  location?: string | null;
  serial_no?: string | null;
  notes?: string | null;

  acquisition_date: string;
  is_qualifying_asset?: boolean;
  ready_for_use_date?: string | null;
  available_for_use_date?: string | null;

  cost: number;
  residual_value: number;
  measurement_model?: "cost" | "revaluation" | null;
  opening_revaluation_surplus?: number | null;
  opening_as_at?: string | null;
  opening_cost?: number | null;
  vat_recovery_percent?: number | null;
  vat_input_claimable?: boolean;
  vat_recovery_reason?: VatRecoveryReason | string | null;

  opening_accum_dep?: number | null;
  opening_impairment?: number | null;

  depreciation_method: DepreciationMethod;
  useful_life_months: number;

  rb_rate_percent?: number | null;
  uop_usage_mode?: UopUsageMode | null;
  uop_opening_reading?: number | null;
  uop_total_units?: number | null;
  uop_unit_name?: string | null;

  asset_account_code?: string | null;
  accum_dep_account_code?: string | null;
  dep_expense_account_code?: string | null;
  disposal_gain_account_code?: string | null;
  disposal_loss_account_code?: string | null;

  bank_account_id?: number | string | null;
  funding_source?: FundingSource;
  supplier_id?: number | string | null;
  vendor_invoice_no?: string | null;
  grn_no?: string | null;
  other_credit_account_code?: string | null;

  // NEW: IAS standard & nature
  accounting_standard?: AccountingStandard | null;
  indefinite_useful_life?: boolean;    // IAS 38
  is_intangible_dev_phase?: boolean;   // IAS 38
  dev_cap_start_date?: string | null;  // IAS 38
  dev_cap_end_date?: string | null;    // IAS 38
  fair_value_model?: boolean;          // IAS 40
  rental_income_account_code?: string | null;  // IAS 40
  fv_gain_loss_account_code?: string | null;    // IAS 40
};


/** -----------------------------
 *  URL builders (pure)
 *  ----------------------------- */
function assetsCreateUrl(companyId: number | string): string {
  if (ENDPOINTS?.assets?.create) return ENDPOINTS.assets.create(companyId);
  return `/api/companies/${encodeURIComponent(String(companyId))}/assets`;
}

function compoundAssetCreateUrl(companyId: number | string): string {
  return `/api/companies/${encodeURIComponent(String(companyId))}/assets/compound-acquisition`;
}

function coaListUrl(companyId: number | string): string {
  if (ENDPOINTS?.coa?.list) return ENDPOINTS.coa.list(companyId);
  return `/api/companies/${encodeURIComponent(String(companyId))}/coa`;
}

function vendorsUrl(companyId: number | string): string {
  if (ENDPOINTS?.vendors?.list) return ENDPOINTS.vendors.list(companyId, { limit: 500, offset: 0, q: "" });
  return `/api/companies/${encodeURIComponent(String(companyId))}/vendors?limit=500&offset=0`;
}

function banksUrl(companyId: number | string): string {
  if (ENDPOINTS?.banks?.list) return ENDPOINTS.banks.list(companyId, { limit: 500, offset: 0 });
  return `/api/companies/${encodeURIComponent(String(companyId))}/bank_accounts?limit=500&offset=0`;
}

function assetAcqCreateUrl(companyId: number | string, assetId: number | string): string {
  return `/api/companies/${encodeURIComponent(String(companyId))}/assets/${encodeURIComponent(String(assetId))}/acquisitions`;
}

function assetAcqPostUrl(companyId: number | string, acqId: number | string): string {
  return `/api/companies/${encodeURIComponent(String(companyId))}/asset-acquisitions/${encodeURIComponent(String(acqId))}/post`;
}

function assetAcqPreviewUrl(companyId: number | string, acqId: number | string): string {
  return `/api/companies/${encodeURIComponent(String(companyId))}/asset-acquisitions/${encodeURIComponent(String(acqId))}/journal-preview`;
}

function assetAcqUpdateUrl(companyId: number | string, acqId: number | string): string {
  return `/api/companies/${encodeURIComponent(String(companyId))}/asset-acquisitions/${encodeURIComponent(String(acqId))}`;
}

async function handoffToApBillFromAcquisition(
  companyId: number | string,
  assetId: number | string,
  acquisitionId: number | string
) {
  sessionStorage.setItem(
    "fs_ap_asset_bill_prefill",
    JSON.stringify({
      company_id: Number(companyId),
      asset_id: Number(assetId),
      acquisition_id: Number(acquisitionId),
      ts: Date.now(),
    })
  );

  const w = window as unknown as {
    navigateTo?: (name: string) => void;
    switchScreen?: (name: string) => Promise<void> | void;
  };

  if (typeof w.navigateTo === "function") {
    w.navigateTo("ap");
    return;
  }

  if (typeof w.switchScreen === "function") {
    await w.switchScreen("ap");
    return;
  }

  console.warn("AP screen navigation function not found");
}

/** -----------------------------
 *  Helpers
 *  ----------------------------- */
function toNum(v: string): number {
  const n = Number(String(v).replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
}

function isContraAccount(a: CoaRow): boolean {
  const name = String(a.name || a.account_name || "").toLowerCase();
  const category = String(a.category || "").toLowerCase();
  const code = String(a.code || "").toUpperCase();

  return (
    name.includes("accumulated depreciation") ||
    name.includes("accumulated amortization") ||
    name.includes("allowance") ||
    category.includes("accumulated depreciation") ||
    code.includes("_ACCUM_")
  );
}

function isNcaCostAccount(a: CoaRow): boolean {
  const bucket = String(a.cf_bucket || "").toLowerCase();

  if (a.is_contra) return false;

  return [
    "ppe",
    "rou_asset",
    "investment_property",
    "intangible"
  ].includes(bucket);
}

function pickContraForAsset(assetAcctCode: string, allAccounts: CoaRow[]): string {
  const asset = allAccounts.find((a) => a.code === assetAcctCode);
  const assetName = String(asset?.name || asset?.account_name || "").toLowerCase();

  const contraCandidates = allAccounts.filter(isContraAccount);

  const findBy = (kw: string) =>
    contraCandidates.find((c) => String(c.name || c.account_name || "").toLowerCase().includes(kw))?.code || "";

  if (assetName.includes("intangible")) return findBy("amortization") || findBy("intangibles") || "";
  if (assetName.includes("building")) return findBy("buildings") || findBy("building") || "";
  if (assetName.includes("right-of-use") || assetName.includes("right of use") || assetName.includes("rou"))
    return findBy("right-of-use") || findBy("rou") || "";
  if (assetName.includes("vehicle") || assetName.includes("motor")) return findBy("vehicle") || findBy("equipment") || "";

  return findBy("equipment") || "";
}

function deriveAccountingStandard(classGroup: string): AccountingStandard {
  const g = classGroup.toLowerCase();
  if (g.includes("investment property")) return "ias40";
  if ([
    "goodwill", "patents", "copyrights", "trademarks", "software",
    "licences", "franchises", "customer lists", "research and development",
    "other intangible",
  ].some(k => g.includes(k.toLowerCase()))) return "ias38";
  return "ias16";
}

/** For safe parsing of API shapes (no any) */
type CoaListResponse = { rows?: CoaRow[]; data?: CoaRow[]; accounts?: CoaRow[] };
type VendorsResponse = { vendors?: Vendor[]; rows?: Vendor[]; data?: Vendor[] };
type BanksResponse = { banks?: BankAccount[]; rows?: BankAccount[]; data?: BankAccount[] };

export default function FixedAssetsDrawer({ open, args, onClose, onResolve }: Props) {
  const title = useMemo(() => {
    if (!args) return "Fixed Assets";
    return args.mode === "acquire" ? "Fixed Assets • Acquire / Add" : "Fixed Assets • Dispose / Impair";
  }, [args]);

  const [err, setErr] = useState<string>("");

  // COA
  const [coaNca, setCoaNca] = useState<CoaRow[]>([]);
  const [coaAll, setCoaAll] = useState<CoaRow[]>([]);
  const [coaLoading, setCoaLoading] = useState(false);

  // Conditional lists
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [vendorsLoading, setVendorsLoading] = useState(false);
  const [banksLoading, setBanksLoading] = useState(false);

  const [selectedVendorId, setSelectedVendorId] = useState<string>("");
  const [selectedBankId, setSelectedBankId] = useState<string>("");

  const [fundingSource, setFundingSource] = useState<FundingSource>("bank");
  const [sourceDocType, setSourceDocType] = useState<SourceDocType>("invoice");
  const [sourceDocRef, setSourceDocRef] = useState<string>("");
  const [showSourceDocNote, setShowSourceDocNote] = useState(false);

  const [otherCreditAccountCode, setOtherCreditAccountCode] = useState("");

  // Entry mode
  const [entryMode, setEntryMode] = useState<AssetEntryMode>("acquisition");
  const isOpeningBalance = entryMode === "opening_balance";

  // 2-step flow
  const [step, setStep] = useState<1 | 2>(1);
  const [createdAssetId, setCreatedAssetId] = useState<string>("");
  const [createdAcqId, setCreatedAcqId] = useState<string>("");

  // Preview
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewLines, setPreviewLines] = useState<JournalLine[]>([]);
  const [previewMeta, setPreviewMeta] = useState<{ ref?: string; description?: string; total_debit?: number; total_credit?: number } | null>(null);

  // Buttons
  const [saving, setSaving] = useState(false);
  const [posting, setPosting] = useState(false);

  const [components, setComponents] = useState<AssetComponentDraft[]>([]);

  const [form, setForm] = useState<CreateAssetPayload>(() => ({
    entry_mode: "acquisition",

    asset_code: "",
    asset_name: "",
    asset_class: "",
    asset_class_group: "",
    category: "",

    location: "",
    serial_no: "",
    notes: "",

    acquisition_date: new Date().toISOString().slice(0, 10),
    available_for_use_date: "",

    cost: 0,
    residual_value: 0,

    opening_as_at: "",
    opening_cost: null,
    vat_recovery_percent: 100,
    vat_input_claimable: false,
    vat_recovery_reason: "",

    opening_accum_dep: null,
    opening_impairment: null,

    depreciation_method: "",
    useful_life_months: 0,
    measurement_model: "cost",
    opening_revaluation_surplus: null,

    rb_rate_percent: null,
    uop_usage_mode: "DELTA",
    uop_opening_reading: null,
    uop_total_units: null,
    uop_unit_name: "",

    asset_account_code: "",
    accum_dep_account_code: "",
    dep_expense_account_code: "",
    disposal_gain_account_code: "",
    disposal_loss_account_code: "",
    is_qualifying_asset: false, // ✅ ADD THIS

  }));

  const carryingAmount = useMemo(() => {
    const cost = Number(form.cost || 0);
    const accum = Number(form.opening_accum_dep || 0);
    const impairment = Number(form.opening_impairment || 0);
    return Math.max(0, cost - accum - impairment);
  }, [form.cost, form.opening_accum_dep, form.opening_impairment]);

  const selectedClassGroup = String(form.asset_class_group || "").toLowerCase();
  const selectedClassLabel = String(form.asset_class || "").toLowerCase();

  const isLandOnly = selectedClassGroup === "land";
  const isBuilding = selectedClassGroup === "buildings";
  const isCompoundLandBuilding = selectedClassGroup === "land and buildings";
  const componentTotalCost = useMemo(
    () => components.reduce((s, c) => s + Number(c.cost || 0), 0),
    [components]
  );
  useEffect(() => {
    if (!isCompoundLandBuilding) return;

    setForm((p) => ({
      ...p,
      cost: componentTotalCost,
      asset_class: "Land and buildings",
      depreciation_method: "APP",
      useful_life_months: 0,
      residual_value: 0,
    }));
  }, [isCompoundLandBuilding, componentTotalCost]);
  const isLandOrBuilding = isLandOnly || isBuilding || isCompoundLandBuilding;

  const isIntangibleAsset =
    selectedClassGroup.includes("intangible") ||
    selectedClassLabel.includes("intangible") ||
    String(form.asset_account_code || "").toLowerCase().includes("intangible");

  const isIAS40 =
    selectedClassGroup.includes("investment property") ||
    selectedClassLabel.includes("investment property");

  const isIAS38 =
    isIntangibleAsset;
    
  const supportsRevaluationModel = isLandOrBuilding || isIntangibleAsset;

  /** -----------------------------
   *  Build acquisition payload
   *  ----------------------------- */
  function buildAcqPayload(assetId: number | string) {
    const amount = Number(form.cost || 0);
    const postingDate = String(
      form.posting_date || readPostingDateFromArgs(args) || form.acquisition_date || ""
    ).trim();
    const journalRef = readJournalRefFromArgs(args);

    if (!postingDate) throw new Error("Posting date is required.");

    const funding =
      fundingSource === "bank" || fundingSource === "cash"
        ? "bank_cash"
        : fundingSource === "vendor_credit"
          ? "vendor_credit"
          : fundingSource === "grni"
            ? "grni"
            : "other";

    const payload: Record<string, unknown> = {
      acquisition_date: form.acquisition_date,
      posting_date: postingDate,
      amount,
      funding_source: funding,
      reference: sourceDocRef?.trim() || journalRef || `ASSET-${String(assetId)}`,
      notes: form.notes?.trim() || null,
      status: "draft",
      vat_recovery_percent:
        form.vat_recovery_reason === "mixed_use"
          ? Number(form.vat_recovery_percent ?? 0)
          : form.vat_input_claimable
            ? 100
            : 0,
      vat_input_claimable: !!form.vat_input_claimable,
      vat_recovery_reason: form.vat_recovery_reason?.trim() || null,

      accounting_standard: accountingStandard,
      indefinite_useful_life: isIAS38 ? !!form.indefinite_useful_life : false,
      is_intangible_dev_phase: isIAS38 ? !!form.is_intangible_dev_phase : false,
      fair_value_model: isIAS40 ? !!form.fair_value_model : false,
    };

    if (funding === "bank_cash") {
      if (!selectedBankId) throw new Error("Select a bank account.");
      payload.bank_account_id = selectedBankId;

      const bank = banks.find((b) => String(b.id) === String(selectedBankId));
      const bankCode = String(bank?.ledger_account_code || "").trim();
      if (bankCode) payload.bank_account_code = bankCode;
    }

    if (funding === "vendor_credit") {
      payload.supplier_id = selectedVendorId;
      payload.vendor_invoice_no = sourceDocRef.trim();
    }

    if (funding === "grni") {
      payload.supplier_id = selectedVendorId;
      payload.grn_no = sourceDocRef.trim();
    }

    if (funding === "other") {
      const c = otherCreditAccountCode.trim();
      if (!c) throw new Error("Credit account code is required for Other.");
      payload.credit_account_code = c;
    }

    return payload;
  }

  /** -----------------------------
   *  Load COA (and reset workflow when opening)
   *  ----------------------------- */
  useEffect(() => {
    if (!open || !args) return;

    // reset step flow on each open
    setStep(1);
    setCreatedAssetId("");
    setCreatedAcqId("");
    setPreviewLines([]);
    setPreviewMeta(null);
    setPosting(false);
    setSaving(false);
    setErr("");

    const apiFetchFn = getApiFetch();
    if (!apiFetchFn) {
      setErr("window.apiFetch is not available in this React app.");
      return;
    }

    (async () => {
      try {
        setCoaLoading(true);
        const res = await apiFetchFn(coaListUrl(args.companyId), { method: "GET" });

        const list: CoaRow[] = Array.isArray(res)
          ? (res as CoaRow[])
          : (
              (res as CoaListResponse)?.rows ??
              (res as CoaListResponse)?.data ??
              (res as CoaListResponse)?.accounts ??
              []
            );

        console.log("COA ALL", list.length);

        console.table(
          list.map(a => ({
            code: a.code,
            name: a.name,
            bucket: a.cf_bucket,
            section: a.section,
            contra: a.is_contra
          }))
        );

        console.log("COA NCA", list.filter(isNcaCostAccount).length);

        console.table(
          list.filter(isNcaCostAccount).map(a => ({
            code: a.code,
            name: a.name,
            bucket: a.cf_bucket,
            contra: a.is_contra
          }))
        );

        setCoaAll(list);
        setCoaNca(list.filter(isNcaCostAccount));
      } catch (e: unknown) {
        setErr(e instanceof Error ? e.message : "Failed to load COA");
      } finally {
        setCoaLoading(false);
      }
    })();
  }, [open, args]);

  useEffect(() => {
    if (isLandOnly && form.depreciation_method !== "APP") {
      setForm((p) => ({
        ...p,
        depreciation_method: "APP",
        useful_life_months: 0,
        rb_rate_percent: null,
        uop_total_units: null,
        uop_usage_mode: null,
        uop_opening_reading: null,
        uop_unit_name: null,
      }));
    }
  }, [isLandOnly, form.depreciation_method]);

  // Derive standard from selected class group
  const accountingStandard = useMemo(
    () => deriveAccountingStandard(form.asset_class_group || ""),
    [form.asset_class_group]
  );

  // Auto-adjust form when standard changes
  useEffect(() => {
    if (isIAS38) {
      setForm((p) => ({
        ...p,
        accounting_standard: "ias38",
        residual_value: 0,        // IAS 38: residual value is ALWAYS zero
        depreciation_method: p.indefinite_useful_life ? "APP" : "SL",
        // Don't allow revaluation model for most intangibles (requires active market)
        measurement_model: "cost",
      }));
    } else if (isIAS40) {
      setForm((p) => ({
        ...p,
        accounting_standard: "ias40",
        // IAS 40 allows both cost and fair value model
        // Don't override measurement_model - let user choose
      }));
    } else {
      setForm((p) => ({
        ...p,
        accounting_standard: "ias16",
        // Reset IAS 40/38 specific fields
        indefinite_useful_life: false,
        is_intangible_dev_phase: false,
        fair_value_model: false,
      }));
    }
  }, [isIAS38, isIAS40]);

  useEffect(() => {
    if (!open || !args) return;

    const postingDate = readPostingDateFromArgs(args);
    const defaults = args.defaults || {};

    setEntryMode("acquisition");
    setSelectedVendorId("");
    setSelectedBankId("");
    setFundingSource("bank");
    setSourceDocType("invoice");
    setSourceDocRef("");
    setOtherCreditAccountCode("");
    setShowSourceDocNote(false);

    setForm({
      entry_mode: "acquisition",
      posting_date: String(defaults.posting_date || defaults.postingDate || postingDate || ""),

      asset_code: String(defaults.assetCode || ""),
      asset_name: String(defaults.assetName || ""),
      asset_class: String(defaults.assetClass || ""),
      asset_class_group: String(defaults.assetClassGroup || defaults.asset_class_group || ""),
      category: String(defaults.category || ""),
      location: String(defaults.location || ""),
      serial_no: String(defaults.serialNo || ""),
      notes: String(defaults.notes || ""),
      acquisition_date: String(defaults.acquisitionDate || postingDate || todayIso()),

      available_for_use_date: String(defaults.availableForUseDate || ""),
      is_qualifying_asset: Boolean(defaults.is_qualifying_asset || defaults.isQualifyingAsset || false),
      cost: Number(defaults.cost || 0),
      vat_recovery_percent:
        defaults.vat_recovery_percent == null
          ? 100
          : Number(defaults.vat_recovery_percent),
      vat_input_claimable: Boolean(defaults.vat_input_claimable || defaults.vatInputClaimable || false),
      vat_recovery_reason: String(defaults.vat_recovery_reason || defaults.vatRecoveryReason || ""),
      residual_value: Number(defaults.residualValue || 0),

      opening_as_at: String(defaults.openingAsAt || postingDate || ""),
      opening_cost: defaults.openingCost == null ? null : Number(defaults.openingCost),
      opening_accum_dep: defaults.openingAccumDep == null ? null : Number(defaults.openingAccumDep),
      opening_impairment: defaults.openingImpairment == null ? null : Number(defaults.openingImpairment),

      depreciation_method: (String(defaults.depreciationMethod || "") as DepreciationMethod),
      useful_life_months: defaults.usefulLifeMonths == null ? 0 : Number(defaults.usefulLifeMonths),

      rb_rate_percent: defaults.rbRatePercent == null ? null : Number(defaults.rbRatePercent),
      uop_usage_mode: ((defaults.uopUsageMode as UopUsageMode) || "DELTA"),
      uop_opening_reading: defaults.uopOpeningReading == null ? null : Number(defaults.uopOpeningReading),
      uop_total_units: defaults.uopTotalUnits == null ? null : Number(defaults.uopTotalUnits),
      uop_unit_name: String(defaults.uopUnitName || ""),

      asset_account_code: String(args.accountCode || defaults.asset_account_code || ""),
      accum_dep_account_code: String(defaults.accum_dep_account_code || ""),
      dep_expense_account_code: String(defaults.dep_expense_account_code || ""),
      disposal_gain_account_code: String(defaults.disposal_gain_account_code || ""),
      disposal_loss_account_code: String(defaults.disposal_loss_account_code || ""),
    });
  }, [open, args]);
  /** -----------------------------
   *  Lazy-load vendors / banks
   *  ----------------------------- */
  useEffect(() => {
    if (!open || !args) return;

    const apiFetchFn = getApiFetch();
    if (!apiFetchFn) return;

    const companyId = args.companyId;

    if ((fundingSource === "vendor_credit" || fundingSource === "grni") && vendors.length === 0 && !vendorsLoading) {
      (async () => {
        try {
          setVendorsLoading(true);
          const res = await apiFetchFn(vendorsUrl(companyId), { method: "GET" });

          const wrapped = res as Partial<VendorsResponse>;
          const list: Vendor[] = Array.isArray(res) ? (res as Vendor[]) : (wrapped.vendors ?? wrapped.rows ?? wrapped.data ?? []);

          setVendors(list);
        } catch (e: unknown) {
          setErr(e instanceof Error ? e.message : "Failed to load vendors");
        } finally {
          setVendorsLoading(false);
        }
      })();
    }

    if ((fundingSource === "bank" || fundingSource === "cash") && banks.length === 0 && !banksLoading) {
      (async () => {
        try {
          setBanksLoading(true);
          const res = await apiFetchFn(banksUrl(companyId), { method: "GET" });

          const wrapped = res as Partial<BanksResponse>;
          const list: BankAccount[] = Array.isArray(res) ? (res as BankAccount[]) : (wrapped.banks ?? wrapped.rows ?? wrapped.data ?? []);

          setBanks(list);
        } catch (e: unknown) {
          setErr(e instanceof Error ? e.message : "Failed to load bank accounts");
        } finally {
          setBanksLoading(false);
        }
      })();
    }
  }, [open, args, fundingSource, vendors.length, banks.length, vendorsLoading, banksLoading]);

  async function loadJournalPreview(companyId: string, acqId: string) {
    const apiFetchFn = getApiFetch();
    if (!apiFetchFn) return;

    setPreviewLoading(true);
    try {
      const res = await apiFetchFn(assetAcqPreviewUrl(companyId, acqId), { method: "GET" });

      const out = res as {
        ok?: boolean;
        ref?: string;
        description?: string;
        total_debit?: number;
        total_credit?: number;
        lines?: JournalLine[];
        data?: { lines?: JournalLine[]; ref?: string; description?: string; total_debit?: number; total_credit?: number };
      };

      const lines = out.lines ?? out.data?.lines ?? [];
      setPreviewLines(Array.isArray(lines) ? lines : []);
      setPreviewMeta({
        ref: out.ref ?? out.data?.ref,
        description: out.description ?? out.data?.description,
        total_debit: out.total_debit ?? out.data?.total_debit,
        total_credit: out.total_credit ?? out.data?.total_credit,
      });
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed to load journal preview");
    } finally {
      setPreviewLoading(false);
    }
  }

  async function submitCreateDraft() {
    const apiFetchFn = getApiFetch();
    if (!apiFetchFn) return setErr("window.apiFetch is not available.");
    if (!args) return setErr("Drawer args missing.");

    setErr("");

    if (createdAssetId && createdAcqId) {
      const companyId = args.companyId;
      const acqPayload = buildAcqPayload(createdAssetId);

      const acqRes = await apiFetchFn(assetAcqUpdateUrl(companyId, createdAcqId), {
        method: "PATCH",
        body: JSON.stringify(acqPayload),
      });

      const updated = acqRes as {
        ok?: boolean;
        data?: { id?: number | string };
      };

      if (!updated.ok) {
        throw new Error("Draft acquisition update failed.");
      }

      await loadJournalPreview(String(companyId), String(createdAcqId));
      setStep(2);
      setErr("");
      return;
    }
    if (!form.asset_code.trim()) return setErr("Asset code is required.");
    if (!form.asset_name.trim()) return setErr("Asset name is required.");
    if (!String(form.asset_class_group || "").trim()) {
      return setErr("Asset class group is required.");
    }

    if (!isCompoundLandBuilding && !String(form.asset_class || "").trim()) {
      return setErr("Asset class is required.");
    }

    // IAS 38 validations
    if (isIAS38) {
      if (Number(form.residual_value || 0) !== 0) {
        return setErr("Residual value must be zero for intangible assets (IAS 38.100).");
      }
      if (!form.indefinite_useful_life && form.depreciation_method === "SL" && Number(form.useful_life_months || 0) <= 0) {
        return setErr("Useful life is required for finite-lived intangible assets.");
      }
    }

    // IAS 40 validations
    if (isIAS40 && form.fair_value_model) {
      // FV model: no depreciation fields needed
      // but FV gain/loss account is required
      if (!form.fv_gain_loss_account_code) {
        return setErr("FV gain/loss account is required for fair value model (IAS 40.35).");
      }
    }

    if (isCompoundLandBuilding) {
      const landComponent = components.find((c) => c.component_type === "land");
      const buildingComponent = components.find((c) => c.component_type === "building");

      const landCost = Number(landComponent?.cost || 0);
      const buildingCost = Number(buildingComponent?.cost || 0);

      if (landCost <= 0) return setErr("Land cost must be greater than 0.");
      if (buildingCost <= 0) return setErr("Building cost must be greater than 0.");

      if (landCost + buildingCost !== Number(form.cost || 0)) {
        return setErr("Land cost + Building cost must equal total cost.");
      }
      if (Number(buildingComponent?.useful_life_months || 0) <= 0) {
        return setErr("Building useful life is required.");
      }
    }

    if (!form.acquisition_date) return setErr("Acquisition date is required.");

    const resolvedPostingDate =
      String(form.posting_date || readPostingDateFromArgs(args) || form.acquisition_date || "").trim();

    if (!resolvedPostingDate) {
      return setErr("Posting date is required before creating acquisition draft.");
    }

    if (Number(form.cost) <= 0) {
      return setErr(isOpeningBalance ? "Historical cost must be greater than 0." : "Cost must be greater than 0.");
    }

    if (
      form.vat_input_claimable === true &&
      !String(form.vat_recovery_reason || "").trim()
    ) {
      return setErr("VAT recovery reason is required.");
    }

    if (!form.depreciation_method) {
      return setErr("Select depreciation method.");
    }

    if (!isLandOnly && form.depreciation_method === "SL" && Number(form.useful_life_months || 0) <= 0) {
      return setErr("Useful life is required for straight-line depreciation.");
    }

    if (!isLandOnly && form.depreciation_method === "RB" && Number(form.rb_rate_percent || 0) <= 0) {
      return setErr("Depreciation rate is required for reducing balance.");
    }

    if (!isLandOnly && form.depreciation_method === "UOP" && Number(form.uop_total_units || 0) <= 0) {
      return setErr("Total units are required for units of production.");
    }

    if (
      isOpeningBalance &&
      supportsRevaluationModel &&
      form.measurement_model === "revaluation" &&
      Number(form.opening_revaluation_surplus || 0) <= 0
    ) {
      return setErr("Opening revaluation surplus is required for revaluation model.");
    }

    if (isOpeningBalance) {
      if (!String(form.opening_as_at || "").trim()) return setErr("Opening as at is required.");
      if (Number(form.opening_accum_dep || 0) < 0) return setErr("Accumulated depreciation cannot be negative.");
      if (Number(form.opening_impairment || 0) < 0) return setErr("Opening impairment cannot be negative.");
      if (Number(form.opening_accum_dep || 0) > Number(form.cost || 0)) {
        return setErr("Accumulated depreciation cannot exceed historical cost.");
      }
    } else {
      if ((fundingSource === "vendor_credit" || fundingSource === "grni") && !selectedVendorId) {
        return setErr("Select a vendor.");
      }

      if ((fundingSource === "vendor_credit" || fundingSource === "grni") && !sourceDocRef.trim()) {
        return setErr(fundingSource === "vendor_credit" ? "Invoice number is required." : "GRN / receipt reference is required.");
      }

      if ((fundingSource === "bank" || fundingSource === "cash") && !selectedBankId) {
        return setErr("Select a bank account.");
      }

      if (fundingSource === "other" && !otherCreditAccountCode.trim()) {
        return setErr("Credit account code is required for Other.");
      }
    }

    setSaving(true);

    try {
      const companyId = args.companyId;
      const journalRef = readJournalRefFromArgs(args);

      const depreciationFields =
      form.depreciation_method === "APP"
          ? {
              depreciation_method: "APP" as DepreciationMethod,
              useful_life_months: 0,
              rb_rate_percent: null,
              uop_total_units: null,
              uop_usage_mode: null,
              uop_opening_reading: null,
              uop_unit_name: null,
            }
        : form.depreciation_method === "SL"
          ? {
              depreciation_method: "SL" as DepreciationMethod,
              useful_life_months: Number(form.useful_life_months || 0),
              rb_rate_percent: null,
              uop_total_units: null,
              uop_usage_mode: null,
              uop_opening_reading: null,
              uop_unit_name: null,
            }
          : form.depreciation_method === "RB"
            ? {
                depreciation_method: "RB" as DepreciationMethod,
                useful_life_months: 0,
                rb_rate_percent: Number(form.rb_rate_percent || 0),
                uop_total_units: null,
                uop_usage_mode: null,
                uop_opening_reading: null,
                uop_unit_name: null,
              }
            : {
                depreciation_method: "UOP" as DepreciationMethod,
                useful_life_months: 0,
                rb_rate_percent: null,
                uop_total_units: Number(form.uop_total_units || 0),
                uop_usage_mode: form.uop_usage_mode || "DELTA",
                uop_opening_reading: form.uop_usage_mode === "READING" ? form.uop_opening_reading : null,
                uop_unit_name: form.uop_unit_name?.trim() || null,
              };

      const payload: CreateAssetPayload = {
        ...form,
        entry_mode: entryMode,
        posting_date: resolvedPostingDate,
        reference: journalRef || null,
        category: form.category?.trim() ? form.category.trim() : null,
        location: form.location?.trim() ? form.location.trim() : null,
        serial_no: form.serial_no?.trim() ? form.serial_no.trim() : null,
        notes: form.notes?.trim() ? form.notes.trim() : null,
        available_for_use_date: form.available_for_use_date?.trim() ? form.available_for_use_date.trim() : null,
        is_qualifying_asset: !!form.is_qualifying_asset,
        ready_for_use_date: form.available_for_use_date?.trim() ? form.available_for_use_date.trim() : null,

        ...depreciationFields,

        measurement_model: supportsRevaluationModel ? form.measurement_model || "cost" : "cost",
        opening_revaluation_surplus:
          isOpeningBalance && supportsRevaluationModel && form.measurement_model === "revaluation"
            ? Number(form.opening_revaluation_surplus || 0)
            : null,

        opening_as_at: isOpeningBalance ? (form.opening_as_at?.trim() || null) : null,
        opening_cost: isOpeningBalance ? Number(form.opening_cost ?? form.cost ?? 0) : null,
        vat_recovery_percent:
          form.vat_recovery_reason === "mixed_use"
            ? Number(form.vat_recovery_percent ?? 0)
            : form.vat_input_claimable
              ? 100
              : 0,
        vat_input_claimable: !!form.vat_input_claimable,
        vat_recovery_reason: form.vat_recovery_reason?.trim() || null,
        opening_accum_dep: isOpeningBalance ? Number(form.opening_accum_dep ?? 0) : null,
        opening_impairment: isOpeningBalance ? Number(form.opening_impairment ?? 0) : null,

        funding_source: !isOpeningBalance ? fundingSource : undefined,
        supplier_id: !isOpeningBalance && (fundingSource === "vendor_credit" || fundingSource === "grni") ? (selectedVendorId || null) : null,
        vendor_invoice_no: !isOpeningBalance && fundingSource === "vendor_credit" ? sourceDocRef.trim() : null,
        grn_no: !isOpeningBalance && fundingSource === "grni" ? sourceDocRef.trim() : null,
        bank_account_id: !isOpeningBalance && (fundingSource === "bank" || fundingSource === "cash") ? (selectedBankId || null) : null,
        other_credit_account_code: !isOpeningBalance && fundingSource === "other" ? otherCreditAccountCode.trim() : null,
      };

      const submitPayload = isCompoundLandBuilding
        ? {
            ...payload,
            cost: componentTotalCost,
            asset_class: "Land and buildings",
            asset_class_group: "Land and buildings",
            depreciation_method: "APP",
            useful_life_months: 0,
            residual_value: 0,
            components,
            acquisition: buildAcqPayload(form.asset_code),
          }
        : payload;

      const res = await apiFetchFn(
        isCompoundLandBuilding
          ? compoundAssetCreateUrl(companyId)
          : assetsCreateUrl(companyId),
        {
          method: "POST",
          body: JSON.stringify(submitPayload),
        }
      );

      const created = res as {
        id?: number | string;
        asset_id?: number | string;
        parent_asset_id?: number | string;
        opening_journal_id?: number | string;
        data?: {
          id?: number | string;
          asset_id?: number | string;
          parent_asset_id?: number | string;
          opening_journal_id?: number | string;
        };
      };

      const assetId =
        created.id ??
        created.asset_id ??
        created.parent_asset_id ??
        created.data?.id ??
        created.data?.asset_id ??
        created.data?.parent_asset_id;
      if (assetId == null) throw new Error("Asset created but response did not include id.");

      if (isCompoundLandBuilding) {
        setCreatedAssetId(String(assetId));

        const compoundAcqIds =
          (created as { acquisition_ids?: Array<number | string> })?.acquisition_ids ??
          (created as { data?: { acquisition_ids?: Array<number | string> } })?.data?.acquisition_ids ??
          [];

        const firstAcqId = compoundAcqIds[0];

        if (firstAcqId == null) {
          throw new Error("Compound acquisition created but no acquisition draft id was returned.");
        }

        setCreatedAcqId(String(firstAcqId));
        setStep(2);

        await loadJournalPreview(String(companyId), String(firstAcqId));
        return;
      }

      if (isOpeningBalance) {
        onResolve({ action: "create_asset", assetId });
        onClose();
        return;
      }

      const acqPayload = buildAcqPayload(assetId);
      const acqRes = await apiFetchFn(assetAcqCreateUrl(companyId, assetId), {
        method: "POST",
        body: JSON.stringify(acqPayload),
      });

      const acq = acqRes as { id?: number | string; data?: { id?: number | string } };
      const acqId = acq.id ?? acq.data?.id;
      if (acqId == null) throw new Error("Acquisition created but response did not include id.");

      setCreatedAssetId(String(assetId));
      setCreatedAcqId(String(acqId));
      setStep(2);

      await loadJournalPreview(String(companyId), String(acqId));
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed to create asset");
    } finally {
      setSaving(false);
    }
  }

  async function submitPostDraft() {
    const apiFetchFn = getApiFetch();
    if (!apiFetchFn) return setErr("window.apiFetch is not available.");
    if (!args) return setErr("Drawer args missing.");
    if (!createdAcqId) return setErr("Draft acquisition not created yet.");

    setErr("");
    setPosting(true);

    try {
      const companyId = args.companyId;

      const postRes = await apiFetchFn(assetAcqPostUrl(companyId, createdAcqId), { method: "POST" });
      const posted = postRes as { ok?: boolean; posted_journal_id?: number | string };

      if (!posted.posted_journal_id) throw new Error("Posting did not return posted_journal_id.");

      onResolve({ action: "create_asset", assetId: createdAssetId });
      onClose();
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed to post acquisition");
    } finally {
      setPosting(false);
    }
  }

  const computedTotals = useMemo(() => {
    const td = previewLines.reduce((s, x) => s + (Number(x.debit) || 0), 0);
    const tc = previewLines.reduce((s, x) => s + (Number(x.credit) || 0), 0);
    return { td, tc };
  }, [previewLines]);

  return (
    <DrawerShell
      open={open}
      title={title}
      onClose={() => {
        onResolve({ action: "close" });
        onClose();
      }}
      width={1080}
    >
      {/* Context */}
      {args && (
        <div style={{ fontSize: 12, opacity: 0.85, marginBottom: 10 }}>
          <div>
            <b>Company:</b> {args.companyName?.trim() ? args.companyName : `Company ${String(args.companyId)}`}
          </div>

          {args.accountName ? (
            <div>
              <b>Account:</b> {args.accountName}
            </div>
          ) : null}

          <div>
            <b>Mode:</b> {args.mode}
          </div>

          {/* ✅ ADD THIS */}
          <div>
            <b>Posting date:</b> {readPostingDateFromArgs(args) || "—"}
          </div>

          <div>
            <b>Reference:</b> {readJournalRefFromArgs(args) || "—"}
          </div>

          {!readPostingDateFromArgs(args) || !readJournalRefFromArgs(args) ? (
            <div
              style={{
                marginTop: 8,
                padding: "8px 10px",
                borderRadius: 10,
                background: "rgba(245,158,11,0.10)",
                border: "1px solid rgba(245,158,11,0.25)",
                color: "#92400e",
                fontSize: 12,
                fontWeight: 600,
              }}
            >
              Tip: Open this drawer from Journal Desk after choosing the journal date and reference. This keeps the asset acquisition posting aligned to the correct period and source document.
            </div>
          ) : null}
        </div>
      )}

      {/* CREATE ASSET */}
      <div
        style={{
          border: "1px solid rgba(0,0,0,0.08)",
          borderRadius: 12,
          padding: 12,
          background: "rgba(0,0,0,0.02)",
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 8 }}>Entry type</div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 12px",
              border: "1px solid rgba(0,0,0,0.12)",
              borderRadius: 10,
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="entry_mode"
              checked={entryMode === "acquisition"}
              onChange={() => {
                setEntryMode("acquisition");
                setForm((p) => ({
                  ...p,
                  entry_mode: "acquisition",
                  opening_as_at: "",
                  opening_cost: null,
                  opening_accum_dep: null,
                  opening_impairment: null,
                }));
              }}
            />
            <span>New Asset / Acquisition</span>
          </label>

          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 12px",
              border: "1px solid rgba(0,0,0,0.12)",
              borderRadius: 10,
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="entry_mode"
              checked={entryMode === "opening_balance"}
              onChange={() => {
                const postingDate = readPostingDateFromArgs(args);

                setEntryMode("opening_balance");
                setForm((p) => ({
                  ...p,
                  entry_mode: "opening_balance",
                  opening_cost: Number(p.cost || 0),
                  opening_as_at: p.opening_as_at || postingDate || p.acquisition_date || "",
                  opening_accum_dep: p.opening_accum_dep ?? 0,
                  opening_impairment: p.opening_impairment ?? 0,
                }));
              }}
            />
            <span>Existing Asset / Opening Balance</span>
          </label>
        </div>

        <div style={{ fontSize: 12, opacity: 0.75, marginTop: 8 }}>
          {isOpeningBalance
            ? "Capture an asset already owned before system adoption. Enter historical cost and accumulated depreciation."
            : "Capture a newly acquired asset and continue to acquisition draft + posting."}
        </div>
      </div>
      <div style={{ border: "1px solid rgba(0,0,0,0.08)", borderRadius: 12, padding: 12 }}>
        <div style={{ fontWeight: 800, marginBottom: 8 }}>Create Asset</div>

        {err ? <div style={{ color: "#b91c1c", fontSize: 12, marginBottom: 8 }}>{err}</div> : null}

        {/* Step badge / mode note */}
        {!isOpeningBalance ? (
          <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
            <div
              style={{
                fontSize: 12,
                fontWeight: 900,
                padding: "6px 10px",
                borderRadius: 999,
                background: step === 1 ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.03)",
              }}
            >
              1) Draft
            </div>
            <div
              style={{
                fontSize: 12,
                fontWeight: 900,
                padding: "6px 10px",
                borderRadius: 999,
                background: step === 2 ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.03)",
              }}
            >
              2) Review + Post
            </div>
          </div>
        ) : (
          <div
            style={{
              fontSize: 12,
              fontWeight: 700,
              marginBottom: 10,
              padding: "8px 10px",
              borderRadius: 10,
              background: "rgba(0,0,0,0.04)",
            }}
          >
            Opening balance mode: asset will be created and opening journal posted immediately.
          </div>
        )}

        <div style={{ display: "grid", gap: 10 }}>
          {/* Asset code / class group */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Asset code *</div>
              <input
                value={form.asset_code}
                onChange={(e) => setForm((p) => ({ ...p, asset_code: e.target.value }))}
                placeholder="e.g. VEH-0001"
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>

            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Asset class group *</div>
              <select
                value={String(form.asset_class_group || "")}
                onChange={(e) => {
                const group = e.target.value;
                  if (String(group).toLowerCase() === "land and buildings") {
                    setComponents([
                      {
                        component_type: "land",
                        asset_name: `${form.asset_name || "Property"} - Land`,
                        asset_class_group: "Land",
                        asset_class: "Land",
                        cost: 0,
                        depreciation_method: "APP",
                        useful_life_months: 0,
                        measurement_model: form.measurement_model || "cost",
                      },
                      {
                        component_type: "building",
                        asset_name: `${form.asset_name || "Property"} - Building`,
                        asset_class_group: "Buildings",
                        asset_class: "Building",
                        cost: 0,
                        depreciation_method: "SL",
                        useful_life_months: 600,
                        measurement_model: form.measurement_model || "cost",
                      },
                    ]);
                  } else {
                    setComponents([]);
                  }
                  setForm((p) => ({
                    ...p,
                    asset_class_group: group,
                    asset_class: String(p.asset_class || "").trim() ? p.asset_class : group,
                  }));
                }}
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              >
                <option value="">Select asset class group...</option>
                {ASSET_CLASS_GROUPS.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Asset name / class label */}
          <div style={{ display: "grid", gridTemplateColumns: isCompoundLandBuilding ? "1fr" : "1fr 1fr", gap: 10 }}>
            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Asset name *</div>
              <input
                value={form.asset_name}
                onChange={(e) => {
                  const assetName = e.target.value;

                  setForm((p) => ({
                    ...p,
                    asset_name: assetName,
                  }));

                  if (isCompoundLandBuilding) {
                    setComponents((prev) =>
                      prev.map((c) => ({
                        ...c,
                        asset_name:
                          c.component_type === "land"
                            ? `${assetName || "Property"} - Land`
                            : `${assetName || "Property"} - Building`,
                      }))
                    );
                  }
                }}                
                placeholder="e.g. Motor Vehicle - Toyota"
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>

            {!isCompoundLandBuilding ? (
              <div>
                <div style={{ fontSize: 12, marginBottom: 4 }}>Asset class *</div>
                <input
                value={form.asset_class}
                onChange={(e) => {
                  const assetClass = e.target.value;
                  const assetClassLower = assetClass.toLowerCase();
                  const groupLower = String(form.asset_class_group || "").toLowerCase();

                  const landOnly =
                    groupLower === "land and buildings" &&
                    assetClassLower.includes("land") &&
                    !assetClassLower.includes("building");

                  setForm((p) => ({
                    ...p,
                    asset_class: assetClass,
                    depreciation_method: landOnly ? "APP" : p.depreciation_method,
                    useful_life_months: landOnly ? 0 : p.useful_life_months,
                    rb_rate_percent: landOnly ? null : p.rb_rate_percent,
                    uop_total_units: landOnly ? null : p.uop_total_units,
                  }));
                }}
                placeholder="e.g. Lorries, Motor vehicles, TLBs, Servers"
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>
          ) : null}
          </div>

          <div style={{ fontSize: 11, opacity: 0.75, marginTop: -6 }}>
            Use class label for the company’s own name. The group keeps reporting consistent.
          </div>

          {supportsRevaluationModel && !isCompoundLandBuilding ? (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "8px 10px",
                borderRadius: 10,
                background: "rgba(0,0,0,0.03)",
                border: "1px solid rgba(0,0,0,0.08)",
              }}
            >
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
                <input
                  type="checkbox"
                  checked={form.measurement_model === "revaluation"}
                  onChange={(e) =>
                    setForm((p) => ({
                      ...p,
                      measurement_model: e.target.checked ? "revaluation" : "cost",
                      opening_revaluation_surplus: e.target.checked
                        ? p.opening_revaluation_surplus
                        : null,
                    }))
                  }
                />
                <span style={{ fontSize: 13, fontWeight: 700 }}>
                  Revaluation model
                </span>
              </label>

              <span style={{ fontSize: 11, opacity: 0.7 }}>
                Untick to use cost model.
              </span>
            </div>
          ) : null}

          {/* IAS 40: Fair Value Model toggle */}
          {isIAS40 && (
            <div>
              <label>
                <input
                  type="checkbox"
                  checked={!!form.fair_value_model}
                  onChange={(e) => {
                    const fv = e.target.checked;
                    setForm((p) => ({
                      ...p,
                      fair_value_model: fv,
                      // If FV model: no depreciation, no residual value
                      ...(fv ? {
                        depreciation_method: "APP",
                        useful_life_months: 0,
                        residual_value: 0,
                        measurement_model: "cost", // FV is separate from revaluation
                      } : {}),
                    }));
                  }}
                />
                Fair Value Model (IAS 40.33)
              </label>
              {form.fair_value_model && (
                <p className="text-xs text-amber-600">
                  No depreciation under fair value model. FV changes recognized in P&L.
                </p>
              )}
            </div>
          )}

          {/* IAS 40: Rental income account */}
          {isIAS40 && (
            <div>
              <label>Rental Income Account</label>
              <select value={form.rental_income_account_code || ""}>
                <option value="">-- Select --</option>
                {coaAll
                  .filter((a) => a.cf_bucket === "other_income" || a.cf_bucket === "rental_income")
                  .map((a) => (
                    <option key={a.code} value={a.code}>
                      {a.code} - {a.name || a.account_name}
                    </option>
                  ))}
              </select>
            </div>
          )}

          {/* IAS 38: Indefinite useful life */}
          {isIAS38 && (
            <div>
              <label>
                <input
                  type="checkbox"
                  checked={!!form.indefinite_useful_life}
                  onChange={(e) => {
                    setForm((p) => ({
                      ...p,
                      indefinite_useful_life: e.target.checked,
                      // Indefinite life = no amortisation
                      ...(e.target.checked
                        ? { depreciation_method: "APP", useful_life_months: 0 }
                        : { depreciation_method: "SL" }),
                    }));
                  }}
                />
                Indefinite Useful Life (IAS 38.88)
              </label>
              {form.indefinite_useful_life && (
                <p className="text-xs text-amber-600">
                  No amortisation. Annual impairment testing required (IAS 36).
                </p>
              )}
            </div>
          )}

          {/* IAS 38: Development phase capitalisation */}
          {isIAS38 && (
            <div>
              <label>
                <input
                  type="checkbox"
                  checked={!!form.is_intangible_dev_phase}
                  onChange={(e) => setForm((p) => ({ ...p, is_intangible_dev_phase: e.target.checked }))}
                />
                Development Phase (IAS 38.57)
              </label>
              {form.is_intangible_dev_phase && (
                <>
                  <label>Dev capitalisation start date</label>
                  <input
                    type="date"
                    value={form.dev_cap_start_date || ""}
                    onChange={(e) => setForm((p) => ({ ...p, dev_cap_start_date: e.target.value }))}
                  />
                  <label>Dev capitalisation end date</label>
                  <input
                    type="date"
                    value={form.dev_cap_end_date || ""}
                    onChange={(e) => setForm((p) => ({ ...p, dev_cap_end_date: e.target.value }))}
                  />
                  <p className="text-xs text-amber-600">
                    Must meet all 6 criteria in IAS 38.57. Research costs are expensed.
                  </p>
                </>
              )}
            </div>
          )}

          {/* IAS 38: Lock residual value to 0 */}
          {isIAS38 && (
            <div className="text-xs text-gray-500">
              Residual value is always zero for intangible assets (IAS 38.100).
            </div>
          )}

          {/* VIN / Location */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Serial number / VIN</div>
              <input
                value={form.serial_no || ""}
                onChange={(e) => setForm((p) => ({ ...p, serial_no: e.target.value }))}
                placeholder="e.g. VIN / Serial / IMEI"
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>

            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Location</div>
              <input
                value={form.location || ""}
                onChange={(e) => setForm((p) => ({ ...p, location: e.target.value }))}
                placeholder="e.g. Head Office"
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <div style={{ fontSize: 12, marginBottom: 4 }}>Notes</div>
            <textarea
              value={form.notes || ""}
              onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
              rows={3}
              placeholder="Optional notes..."
              style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
            />
          </div>

          {/* Dates */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Acquisition date *</div>
              <input
                type="date"
                value={form.acquisition_date}
                onChange={(e) => setForm((p) => ({ ...p, acquisition_date: e.target.value }))}
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>

            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>Available for use date</div>
              <input
                type="date"
                value={form.available_for_use_date || ""}
                onChange={(e) => setForm((p) => ({ ...p, available_for_use_date: e.target.value }))}
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              />
            </div>
          </div>

          {/* Cost / residual */}
          {!isCompoundLandBuilding ? (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div>
                <div style={{ fontSize: 12, marginBottom: 4 }}>{isOpeningBalance ? "Historical cost *" : "Cost *"}</div>
                <input
                  value={String(form.cost)}
                  onChange={(e) => setForm((p) => ({ ...p, cost: toNum(e.target.value) }))}
                  placeholder="0.00"
                  style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                />
              </div>

              <div>
                <div style={{ fontSize: 12, marginBottom: 4 }}>Residual value</div>
                <input
                  value={String(form.residual_value)}
                  onChange={(e) => setForm((p) => ({ ...p, residual_value: toNum(e.target.value) }))}
                  placeholder="0.00"
                  style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                />
              </div>
            </div>
          ) : null}

          {isCompoundLandBuilding ? (
            <div
              style={{
                display: "grid",
                gap: 12,
                padding: 12,
                border: "1px solid rgba(0,0,0,0.10)",
                borderRadius: 12,
                background: "rgba(0,0,0,0.03)",
              }}
            >
              <div style={{ fontWeight: 800 }}>Components</div>

              {components.map((c, idx) => (
                <div
                  key={c.component_type}
                  style={{
                    display: "grid",
                    gridTemplateColumns: c.component_type === "building" ? "1fr 1fr 1fr" : "1fr 1fr 1fr",
                    gap: 10,
                    padding: 10,
                    border: "1px solid rgba(0,0,0,0.08)",
                    borderRadius: 10,
                    background: "#fff",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Component</div>
                    <input
                      value={c.asset_name}
                      readOnly
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px", background: "rgba(0,0,0,0.04)" }}
                    />
                  </div>

                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Cost *</div>
                    <input
                      value={String(c.cost)}
                      onChange={(e) => {
                        const cost = toNum(e.target.value);
                        setComponents((prev) =>
                          prev.map((x, i) => (i === idx ? { ...x, cost } : x))
                        );
                        setForm((p) => ({
                          ...p,
                          cost: components.reduce((s, x, i) => s + (i === idx ? cost : Number(x.cost || 0)), 0),
                        }));
                      }}
                      placeholder="0.00"
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>

                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Measurement model</div>
                    <select
                      value={c.measurement_model}
                      onChange={(e) => {
                        const measurement_model = e.target.value as "cost" | "revaluation";
                        setComponents((prev) =>
                          prev.map((x, i) => (i === idx ? { ...x, measurement_model } : x))
                        );
                      }}
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    >
                      <option value="cost">Cost</option>
                      <option value="revaluation">Revaluation</option>
                    </select>
                  </div>

                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Depreciation</div>
                    <input
                      value={c.depreciation_method === "APP" ? "APP / Not depreciated" : c.depreciation_method}
                      readOnly
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px", background: "rgba(0,0,0,0.04)" }}
                    />
                  </div>

                  {c.component_type === "building" ? (
                    <div>
                      <div style={{ fontSize: 12, marginBottom: 4 }}>Useful life months *</div>
                      <input
                        value={String(c.useful_life_months)}
                        onChange={(e) => {
                          const useful_life_months = Math.max(0, Math.floor(toNum(e.target.value)));
                          setComponents((prev) =>
                            prev.map((x, i) => (i === idx ? { ...x, useful_life_months } : x))
                          );
                        }}
                        placeholder="e.g. 600"
                        style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                      />
                    </div>
                  ) : null}
                </div>
              ))}

              <div style={{ fontSize: 13, fontWeight: 800 }}>
                Total acquisition cost: {componentTotalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
          ) : null}

          {/* IAS 23 / VAT checkbox */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input
                type="checkbox"
                checked={!!form.is_qualifying_asset}
                onChange={(e) => setForm((p) => ({ ...p, is_qualifying_asset: e.target.checked }))}
              />
              <span style={{ fontSize: 13, fontWeight: 600 }}>Qualifying asset (IAS 23)</span>
            </label>

            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input
                type="checkbox"
                checked={!!form.vat_input_claimable}
                onChange={(e) =>
                  setForm((p) => ({
                    ...p,
                    vat_input_claimable: e.target.checked,
                    vat_recovery_reason: e.target.checked
                      ? p.vat_recovery_reason || "production_income_use"
                      : "passenger_vehicle_disallowed",
                    vat_recovery_percent: e.target.checked ? p.vat_recovery_percent ?? 100 : 0,
                  }))
                }
              />
              <span style={{ fontSize: 13, fontWeight: 700 }}>Input VAT claimable</span>
            </label>
          </div>

          {/* VAT reason / percentage */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: form.vat_recovery_reason === "mixed_use" ? "2fr 1fr" : "1fr",
              gap: 10,
            }}
          >
            <div>
              <div style={{ fontSize: 12, marginBottom: 4 }}>VAT recovery reason *</div>
              <select
                value={String(form.vat_recovery_reason || "")}
                onChange={(e) =>
                  setForm((p) => ({
                    ...p,
                    vat_recovery_reason: e.target.value,
                    vat_recovery_percent:
                      e.target.value === "mixed_use"
                        ? p.vat_recovery_percent ?? 100
                        : p.vat_input_claimable
                          ? 100
                          : 0,
                  }))
                }
                style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
              >
                <option value="">Select VAT reason...</option>
                <option value="commercial_vehicle">Commercial vehicle / delivery vehicle</option>
                <option value="production_income_use">Used directly to produce taxable income</option>
                <option value="mixed_use">Mixed use - review required</option>
                <option value="dealer_stock">Vehicle dealer stock</option>
                <option value="rental_fleet">Rental fleet vehicle</option>
                <option value="taxi_transport">Passenger transport / taxi business</option>
                <option value="passenger_vehicle_disallowed">Passenger vehicle - input VAT disallowed</option>
                <option value="not_registered_or_exempt">Not claimable / exempt activity</option>
              </select>
            </div>

            {form.vat_recovery_reason === "mixed_use" ? (
              <div>
                <div style={{ fontSize: 12, marginBottom: 4 }}>VAT recovery % *</div>
                <input
                  value={String(form.vat_recovery_percent ?? 100)}
                  onChange={(e) =>
                    setForm((p) => ({
                      ...p,
                      vat_recovery_percent: Math.max(0, Math.min(100, toNum(e.target.value))),
                    }))
                  }
                  placeholder="e.g. 60"
                  style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                />
              </div>
            ) : null}
          </div>

          {/* Opening balance fields */}
          {isOpeningBalance ? (
            <>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    supportsRevaluationModel && form.measurement_model === "revaluation"
                      ? "1fr 1fr 1fr"
                      : "1fr 1fr",
                  gap: 10,
                }}
              >
                <div>
                  <div style={{ fontSize: 12, marginBottom: 4 }}>Opening impairment</div>
                  <input
                    value={String(form.opening_impairment ?? 0)}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, opening_impairment: toNum(e.target.value) }))
                    }
                    placeholder="0.00"
                    style={{
                      width: "100%",
                      border: "1px solid rgba(0,0,0,0.15)",
                      borderRadius: 10,
                      padding: "10px 12px",
                    }}
                  />
                </div>

                {supportsRevaluationModel && form.measurement_model === "revaluation" ? (
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>
                      Opening revaluation surplus *
                    </div>
                    <input
                      value={String(form.opening_revaluation_surplus ?? "")}
                      onChange={(e) =>
                        setForm((p) => ({
                          ...p,
                          opening_revaluation_surplus: toNum(e.target.value),
                        }))
                      }
                      placeholder="0.00"
                      style={{
                        width: "100%",
                        border: "1px solid rgba(0,0,0,0.15)",
                        borderRadius: 10,
                        padding: "10px 12px",
                      }}
                    />
                  </div>
                ) : null}

                <div>
                  <div style={{ fontSize: 12, marginBottom: 4 }}>Carrying amount</div>
                  <input
                    value={String(carryingAmount)}
                    readOnly
                    style={{
                      width: "100%",
                      border: "1px solid rgba(0,0,0,0.15)",
                      borderRadius: 10,
                      padding: "10px 12px",
                      background: "rgba(0,0,0,0.04)",
                      fontWeight: 700,
                    }}
                  />
                </div>
              </div>
            </>
          ) : null}

          {/* Depreciation */}
          {!isCompoundLandBuilding ? (
            <>
              {/* Depreciation */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <div style={{ fontSize: 12, marginBottom: 4 }}>Depreciation method</div>
                  <select
                    value={form.depreciation_method}
                    onChange={(e) => {
                      const m = e.target.value as DepreciationMethod;

                      if (m === "APP") {
                        setForm((p) => ({
                          ...p,
                          depreciation_method: "APP",
                          useful_life_months: 0,
                          rb_rate_percent: null,
                          uop_total_units: null,
                          uop_usage_mode: null,
                          uop_opening_reading: null,
                          uop_unit_name: null,
                        }));
                        return;
                      }

                      setForm((p) => ({
                        ...p,
                        depreciation_method: m,
                        useful_life_months: m === "SL" ? p.useful_life_months || 60 : 0,
                        rb_rate_percent: m === "RB" ? p.rb_rate_percent ?? 20 : null,
                        uop_total_units: m === "UOP" ? p.uop_total_units ?? 0 : null,
                        uop_usage_mode: m === "UOP" ? p.uop_usage_mode ?? "DELTA" : null,
                        uop_opening_reading: m === "UOP" ? p.uop_opening_reading ?? null : null,
                        uop_unit_name: m === "UOP" ? p.uop_unit_name ?? "" : "",
                      }));
                    }}
                    style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                  >
                    <option value="">Select depreciation method...</option>
                    <option value="SL">Straight-line (SL)</option>
                    <option value="RB">Reducing balance (RB)</option>
                    <option value="UOP">Units of Production (UOP)</option>
                    <option value="APP">Appreciation / Not depreciated</option>
                  </select>
                </div>

                {!isLandOnly && form.depreciation_method === "SL" ? (
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Useful life (months) *</div>
                    <input
                      value={String(form.useful_life_months)}
                      onChange={(e) =>
                        setForm((p) => ({
                          ...p,
                          useful_life_months: Math.max(0, Math.floor(toNum(e.target.value))),
                        }))
                      }
                      placeholder="e.g. 60"
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>
                ) : !isLandOnly && form.depreciation_method === "RB" ? (
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Depreciation rate (% p.a.) *</div>
                    <input
                      value={String(form.rb_rate_percent ?? "")}
                      onChange={(e) => setForm((p) => ({ ...p, rb_rate_percent: toNum(e.target.value) }))}
                      placeholder="e.g. 20"
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>
                ) : null}
              </div>

              {form.depreciation_method === "UOP" ? (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Total units (lifetime) *</div>
                    <input
                      value={String(form.uop_total_units ?? "")}
                      onChange={(e) => setForm((p) => ({ ...p, uop_total_units: toNum(e.target.value) }))}
                      placeholder="e.g. 200000"
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>

                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Unit name</div>
                    <input
                      value={String(form.uop_unit_name ?? "")}
                      onChange={(e) => setForm((p) => ({ ...p, uop_unit_name: e.target.value }))}
                      placeholder="e.g. km, hours, units"
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>

                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Usage capture mode</div>
                    <select
                      value={(form.uop_usage_mode || "DELTA") as "DELTA" | "READING"}
                      onChange={(e) => {
                        const m = e.target.value as "DELTA" | "READING";
                        setForm((p) => ({
                          ...p,
                          uop_usage_mode: m,
                          uop_opening_reading: m === "READING" ? p.uop_opening_reading ?? null : null,
                        }));
                      }}
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    >
                      <option value="DELTA">Period usage</option>
                      <option value="READING">Meter reading</option>
                    </select>
                  </div>

                  {(form.uop_usage_mode || "DELTA") === "READING" ? (
                    <div>
                      <div style={{ fontSize: 12, marginBottom: 4 }}>Opening reading</div>
                      <input
                        value={form.uop_opening_reading == null ? "" : String(form.uop_opening_reading)}
                        onChange={(e) => {
                          const raw = e.target.value.trim();
                          setForm((p) => ({
                            ...p,
                            uop_opening_reading: raw ? toNum(raw) : null,
                          }));
                        }}
                        placeholder="e.g. 25"
                        style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                      />
                    </div>
                  ) : null}
                </div>
              ) : null}
            </>
          ) : null}

          {/* Asset account only */}
          <div>
            <div style={{ fontWeight: 800, marginTop: 6, marginBottom: 6 }}>Accounts (GL mapping)</div>
            <div style={{ fontSize: 12, marginBottom: 4 }}>Asset cost account (Non-current assets only) *</div>
            <select
              disabled={coaLoading}
              value={form.asset_account_code || ""}
              onChange={(e) => {
                const code = e.target.value;
                const contraCode = code ? pickContraForAsset(code, coaAll) : "";
                setForm((p) => ({
                  ...p,
                  asset_account_code: code,
                  accum_dep_account_code: contraCode,
                  dep_expense_account_code: "",
                }));
              }}
              style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
            >
              <option value="">{coaLoading ? "Loading..." : "Select PPE / Non-current asset..."}</option>
              {coaNca
                .slice()
                .sort((x, y) =>
                  String(x.name || x.account_name || "").toLowerCase().localeCompare(String(y.name || y.account_name || "").toLowerCase())
                )
                .map((a) => (
                  <option key={a.code} value={a.code}>
                    {(a.name || a.account_name || "").trim() || `Account ${a.code}`}
                  </option>
                ))}
            </select>
          </div>

          {/* Funding */}
          {!isOpeningBalance ? (
            <>
              <div style={{ fontWeight: 800, marginTop: 6 }}>Funding source</div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <div style={{ fontSize: 12, marginBottom: 4 }}>Funding source *</div>
                  <select
                    value={fundingSource}
                    onChange={(e) => {
                      const v = e.target.value as FundingSource;
                      setFundingSource(v);
                      setShowSourceDocNote(false);

                      if (v === "vendor_credit") {
                        setSourceDocType("invoice");
                        setSourceDocRef("");
                      } else if (v === "grni") {
                        setSourceDocType("grn");
                        setSourceDocRef("");
                        setShowSourceDocNote(false);
                      } else {
                        setShowSourceDocNote(false);
                        setSourceDocRef("");
                      }

                      if (v !== "other") setOtherCreditAccountCode("");
                      if (v !== "vendor_credit" && v !== "grni") setSelectedVendorId("");
                      if (v !== "bank" && v !== "cash") setSelectedBankId("");
                    }}
                    style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                  >
                    <option value="cash">Cash</option>
                    <option value="bank">Bank</option>
                    <option value="vendor_credit">Vendor / Credit (AP)</option>
                    <option value="grni">GRNI (Goods received not invoiced)</option>
                    <option value="other">Other (manual / suspense)</option>
                  </select>
                </div>

                {(fundingSource === "bank" || fundingSource === "cash") ? (
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Bank account *</div>
                    <select
                      disabled={banksLoading}
                      value={selectedBankId}
                      onChange={(e) => setSelectedBankId(e.target.value)}
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    >
                      <option value="">{banksLoading ? "Loading..." : "Select bank account..."}</option>
                      {banks.map((b) => {
                        const label = [b.bank_name, b.account_name, b.account_number].filter(Boolean).join(" • ");
                        const code = (b.ledger_account_code || "").trim();
                        const missing = !code;

                        return (
                          <option key={String(b.id)} value={String(b.id)} disabled={missing}>
                            {label || `Bank ${b.id}`}{missing ? " (Missing ledger code)" : ""}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                ) : null}

                {showSourceDocNote && (
                  <div
                    style={{
                      padding: 10,
                      borderRadius: 8,
                      background: "rgba(59,130,246,.08)",
                      fontSize: 12,
                      border: "1px solid rgba(59,130,246,.15)",
                    }}
                  >
                    GRNI acquisitions create a temporary liability. Input VAT will normally
                    be recognized when the supplier invoice is received.
                  </div>
                )}
                {(fundingSource === "vendor_credit" || fundingSource === "grni") ? (
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Vendor *</div>
                    <select
                      disabled={vendorsLoading}
                      value={selectedVendorId}
                      onChange={(e) => setSelectedVendorId(e.target.value)}
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    >
                      <option value="">{vendorsLoading ? "Loading..." : "Select vendor..."}</option>
                      {vendors.map((v) => (
                        <option key={String(v.id)} value={String(v.id)}>
                          {v.name || v.vendor_name || `Vendor ${v.id}`}
                        </option>
                      ))}
                    </select>
                  </div>
                ) : null}

                {fundingSource === "other" ? (
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Credit account code *</div>
                    <input
                      value={otherCreditAccountCode}
                      onChange={(e) => setOtherCreditAccountCode(e.target.value)}
                      placeholder="e.g. BS_CL_2000"
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>
                ) : null}
              </div>

              {(fundingSource === "vendor_credit" || fundingSource === "grni") ? (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>Source document</div>
                    <select
                      value={sourceDocType}
                      onChange={(e) => setSourceDocType(e.target.value as SourceDocType)}
                      disabled={fundingSource === "vendor_credit"}
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    >
                      <option value="invoice">Invoice</option>
                      <option value="grn">GRN / Goods Receipt</option>
                    </select>
                  </div>

                  <div>
                    <div style={{ fontSize: 12, marginBottom: 4 }}>
                      {sourceDocType === "invoice" ? "Invoice number *" : "GRN / Receipt reference *"}
                    </div>
                    <input
                      value={sourceDocRef}
                      onChange={(e) => setSourceDocRef(e.target.value)}
                      placeholder={sourceDocType === "invoice" ? "e.g. INV-12345" : "e.g. GRN-009812"}
                      style={{ width: "100%", border: "1px solid rgba(0,0,0,0.15)", borderRadius: 10, padding: "10px 12px" }}
                    />
                  </div>
                </div>
              ) : null}
            </>
          ) : null}
        </div>

          {/* ✅ Journal Preview appears ONLY after draft (step 2) */}
          {step === 2 ? (
            <div style={{ marginTop: 12, border: "1px solid rgba(0,0,0,0.10)", borderRadius: 12, padding: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ fontWeight: 900 }}>Journal Preview</div>

                <button
                  type="button"
                  onClick={() => args && createdAcqId && loadJournalPreview(String(args.companyId), String(createdAcqId))}
                  disabled={previewLoading}
                  style={{
                    border: "1px solid rgba(0,0,0,0.18)",
                    borderRadius: 10,
                    padding: "6px 10px",
                    background: "white",
                    cursor: previewLoading ? "not-allowed" : "pointer",
                    fontWeight: 800,
                    fontSize: 12,
                  }}
                >
                  {previewLoading ? "Loading..." : "Refresh"}
                </button>
              </div>

              <div style={{ fontSize: 12, opacity: 0.8, marginTop: 6 }}>
                <div><b>Draft acquisition:</b> {createdAcqId}</div>
                <div><b>Draft asset:</b> {createdAssetId}</div>
                {previewMeta?.ref ? <div><b>Ref:</b> {previewMeta.ref}</div> : null}
                {previewMeta?.description ? <div><b>Description:</b> {previewMeta.description}</div> : null}
              </div>

              <div style={{ marginTop: 10, overflowX: "auto" }}>
                {previewLines.length === 0 ? (
                  <div style={{ fontSize: 12, opacity: 0.7 }}>
                    {previewLoading ? "Loading preview..." : "No preview lines returned yet."}
                  </div>
                ) : (
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                    <thead>
                      <tr style={{ textAlign: "left", borderBottom: "1px solid rgba(0,0,0,0.12)" }}>
                        <th style={{ padding: "8px 6px" }}>Account (Name)</th>
                        <th style={{ padding: "8px 6px", width: 140, textAlign: "right" }}>Debit</th>
                        <th style={{ padding: "8px 6px", width: 140, textAlign: "right" }}>Credit</th>
                        <th style={{ padding: "8px 6px" }}>Memo</th>
                      </tr>
                    </thead>
                      <tbody>
                        {previewLines.map((ln, idx) => (
                          <tr key={idx} style={{ borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
                            <td style={{ padding: "8px 6px", fontWeight: 700 }}>
                              {ln.account_name || ""}
                            </td>
                            <td style={{ padding: "8px 6px", textAlign: "right" }}>{(Number(ln.debit) || 0).toFixed(2)}</td>
                            <td style={{ padding: "8px 6px", textAlign: "right" }}>{(Number(ln.credit) || 0).toFixed(2)}</td>
                            <td style={{ padding: "8px 6px", opacity: 0.85 }}>{ln.memo || ""}</td>
                          </tr>
                        ))}
                      </tbody>
                    <tfoot>
                      <tr>
                        <td style={{ padding: "8px 6px", fontWeight: 900 }}>Totals</td>
                        <td style={{ padding: "8px 6px", textAlign: "right", fontWeight: 900 }}>
                          {(previewMeta?.total_debit ?? computedTotals.td).toFixed(2)}
                        </td>
                        <td style={{ padding: "8px 6px", textAlign: "right", fontWeight: 900 }}>
                          {(previewMeta?.total_credit ?? computedTotals.tc).toFixed(2)}
                        </td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                )}
              </div>
            </div>
          ) : null}

          {/* ✅ Buttons */}
          {isOpeningBalance ? (
            <button
              type="button"
              onClick={submitCreateDraft}
              disabled={saving}
              style={{
                border: 0,
                borderRadius: 12,
                padding: "12px 14px",
                background: "black",
                color: "white",
                cursor: saving ? "not-allowed" : "pointer",
                fontWeight: 900,
                marginTop: 6,
              }}
            >
              {saving ? "Saving..." : "Create Opening Balance"}
            </button>
          ) : step === 1 ? (
            <button
              type="button"
              onClick={submitCreateDraft}
              disabled={saving}
              style={{
                border: 0,
                borderRadius: 12,
                padding: "12px 14px",
                background: "black",
                color: "white",
                cursor: saving ? "not-allowed" : "pointer",
                fontWeight: 900,
                marginTop: 6,
              }}
            >
              {saving ? "Saving..." : "Create Draft"}
            </button>
            ) : (
              <div style={{ display: "flex", gap: 10, marginTop: 6, flexWrap: "wrap" }}>
                <button
                  type="button"
                  onClick={() => {
                    setStep(1);
                    setPreviewLines([]);
                    setPreviewMeta(null);
                    setErr("");
                  }}
                  disabled={posting || saving}
                  style={{
                    border: "1px solid rgba(0,0,0,0.18)",
                    borderRadius: 12,
                    padding: "12px 14px",
                    background: "white",
                    color: "black",
                    cursor: posting || saving ? "not-allowed" : "pointer",
                    fontWeight: 900,
                  }}
                >
                  Back to Edit
                </button>
               
                <button
                  type="button"
                    onClick={async () => {
                      if (!args || !createdAssetId || !createdAcqId) return;
                      await handoffToApBillFromAcquisition(args.companyId, createdAssetId, createdAcqId);
                    }}
                  disabled={!createdAssetId || !createdAcqId}
                  style={{
                    border: "1px solid rgba(0,0,0,0.18)",
                    borderRadius: 12,
                    padding: "12px 14px",
                    background: "white",
                    color: "black",
                    cursor: !createdAssetId || !createdAcqId ? "not-allowed" : "pointer",
                    fontWeight: 900,
                  }}
                >
                  Create Bill
                </button>

                <button
                  type="button"
                  onClick={submitPostDraft}
                  disabled={posting || previewLoading}
                  style={{
                    border: 0,
                    borderRadius: 12,
                    padding: "12px 14px",
                    background: "black",
                    color: "white",
                    cursor: posting ? "not-allowed" : "pointer",
                    fontWeight: 900,
                  }}
                >
                  {posting ? "Posting..." : "Post Acquisition"}
                </button>
              </div>
            )}
      </div>
    </DrawerShell>
  );
}
